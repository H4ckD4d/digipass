# Description
  Exfiltrate ALL web browser passwords, and sends it via discord webhook

# Setup
  1. Create discord webhook.
  2. Replace %webhook% with your discord webhook.
  3. Save and move it to your flip.
